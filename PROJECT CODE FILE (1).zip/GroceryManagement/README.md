# Grocery Management System (Java + MySQL)

## Overview
This is a simple Grocery Management desktop application written in Java (Swing) with MySQL as the backend.

## What is included
- Java source files under `src/` (packages: db, dao, model, ui)
- SQL script: `database/grocery_store.sql`
- DBConnection configured with the provided MySQL credentials.

## Setup (IntelliJ IDEA Community)
1. Make sure you have Java (JDK 8+) installed.
2. Install and start MySQL server.
3. Run the SQL script:
   - Open MySQL Workbench / CLI and run `database/grocery_store.sql` to create the database and tables.
4. Add MySQL JDBC Driver to the project:
   - Download Connector/J from: https://dev.mysql.com/downloads/connector/j/
   - In IntelliJ: File → Project Structure → Libraries → + → select the connector JAR.
5. Open the project folder in IntelliJ (File → Open → `GroceryManagement`).
6. Build and run:
   - Run `ui.MainDashboard` main method to open the dashboard.

## Notes
- DB credentials are set in `src/db/DBConnection.java`:
  - user: `root`
  - password: `raj2003`
  - If your MySQL uses different credentials, update the file accordingly.
- This is a simple starting project — you can enhance it with login, reports, and PDF bills.
