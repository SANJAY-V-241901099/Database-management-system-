package ui;

import dao.*;
import model.*;
import javax.swing.*;
//import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.awt.FlowLayout;

public class SalesFrame extends JFrame {
    private JComboBox<String> customerBox;
    private JComboBox<String> productBox;
    private JTextField qtyField;
    private JTextArea billArea;
    private JButton addBtn, generateBtn;

    private Map<Integer, Integer> cart = new HashMap<>(); // product_id → qty
    private ProductDAO productDAO = new ProductDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private SalesDAO salesDAO = new SalesDAO();
    private List<Product> products;
    private List<Customer> customers;

    public SalesFrame() {
        setTitle("Sales & Billing");
        setSize(700, 500);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Load products and customers
        products = productDAO.getAllProducts();
        customers = customerDAO.getAllCustomers();

        add(new JLabel("Customer:"));
        customerBox = new JComboBox<>();
        for (Customer c : customers) {
            customerBox.addItem(c.getName());
        }
        add(customerBox);

        add(new JLabel("Product:"));
        productBox = new JComboBox<>();
        for (Product p : products) {
            productBox.addItem(p.getProductId() + " - " + p.getName());
        }
        add(productBox);

        add(new JLabel("Quantity:"));
        qtyField = new JTextField(5);
        add(qtyField);

        addBtn = new JButton("Add to Bill");
        generateBtn = new JButton("Generate Bill");

        billArea = new JTextArea(15, 50);
        billArea.setEditable(false);

        add(addBtn);
        add(generateBtn);
        add(new JScrollPane(billArea));

        addBtn.addActionListener(e -> addToBill());
        generateBtn.addActionListener(e -> generateBill());

        setVisible(true);
    }

    private void addToBill() {
        int selectedIndex = productBox.getSelectedIndex();
        if (selectedIndex < 0) return;

        try {
            int productId = products.get(selectedIndex).getProductId();
            int qty = Integer.parseInt(qtyField.getText());

            cart.put(productId, cart.getOrDefault(productId, 0) + qty);
            billArea.append(products.get(selectedIndex).getName() + " x " + qty +
                    " = ₹" + (products.get(selectedIndex).getPrice() * qty) + "\n");
            qtyField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter a valid quantity.");
        }
    }

    private void generateBill() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Cart is empty!");
            return;
        }

        int custIndex = customerBox.getSelectedIndex();
        if (custIndex < 0) {
            JOptionPane.showMessageDialog(this, "Select a customer!");
            return;
        }

        int customerId = customers.get(custIndex).getCustomerId();
        salesDAO.createSale(customerId, cart);

        JOptionPane.showMessageDialog(this, "Bill generated successfully!");
        billArea.append("\n=== BILL GENERATED ===\n");
        cart.clear();
    }

    public static void main(String[] args) {
        new SalesFrame();
    }
}
