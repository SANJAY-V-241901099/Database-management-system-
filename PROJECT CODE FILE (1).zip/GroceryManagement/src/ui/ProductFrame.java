package ui;

import javax.swing.*;
import dao.ProductDAO;
import model.Product;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ProductFrame extends JFrame {
    JTextField nameField, categoryField, qtyField, priceField;
    JTextArea displayArea;
    ProductDAO dao = new ProductDAO();

    public ProductFrame() {
        setTitle("Product Management");
        setSize(500, 400);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        add(new JLabel("Name:"));
        nameField = new JTextField(10);
        add(nameField);

        add(new JLabel("Category:"));
        categoryField = new JTextField(10);
        add(categoryField);

        add(new JLabel("Quantity:"));
        qtyField = new JTextField(5);
        add(qtyField);

        add(new JLabel("Price:"));
        priceField = new JTextField(7);
        add(priceField);

        JButton addBtn = new JButton("Add Product");
        JButton viewBtn = new JButton("View All");
        displayArea = new JTextArea(10, 40);
        addBtn.addActionListener(e -> addProduct());
        viewBtn.addActionListener(e -> viewProducts());

        add(addBtn);
        add(viewBtn);
        add(new JScrollPane(displayArea));

        setVisible(true);
    }

    private void addProduct() {
        try {
            String name = nameField.getText();
            String cat = categoryField.getText();
            int qty = Integer.parseInt(qtyField.getText());
            double price = Double.parseDouble(priceField.getText());
            dao.addProduct(new Product(name, cat, qty, price));
            JOptionPane.showMessageDialog(this, "Product added!");
            clearFields();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numeric values for quantity and price.");
        }
    }

    private void viewProducts() {
        List<Product> list = dao.getAllProducts();
        displayArea.setText("");
        for (Product p : list) {
            displayArea.append(p.getProductId() + " - " + p.getName() +
                    " (" + p.getCategory() + "), Qty: " + p.getQuantity() +
                    ", Price: ₹" + p.getPrice() + "\n");
        }
    }

    private void clearFields() {
        nameField.setText("");
        categoryField.setText("");
        qtyField.setText("");
        priceField.setText("");
    }

    public static void main(String[] args) {
        new ProductFrame();
    }
}
