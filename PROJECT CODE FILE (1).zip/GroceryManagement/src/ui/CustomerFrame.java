package ui;

import dao.CustomerDAO;
import model.Customer;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CustomerFrame extends JFrame {
    private JTextField nameField, phoneField, emailField;
    private JTextArea displayArea;
    private CustomerDAO dao = new CustomerDAO();

    public CustomerFrame() {
        setTitle("Customer Management");
        setSize(500, 400);
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        add(new JLabel("Name:"));
        nameField = new JTextField(10);
        add(nameField);

        add(new JLabel("Phone:"));
        phoneField = new JTextField(10);
        add(phoneField);

        add(new JLabel("Email:"));
        emailField = new JTextField(15);
        add(emailField);

        JButton addBtn = new JButton("Add Customer");
        JButton viewBtn = new JButton("View All");
        displayArea = new JTextArea(10, 40);

        addBtn.addActionListener(e -> addCustomer());
        viewBtn.addActionListener(e -> viewCustomers());

        add(addBtn);
        add(viewBtn);
        add(new JScrollPane(displayArea));

        setVisible(true);
    }

    private void addCustomer() {
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        dao.addCustomer(new Customer(name, phone, email));
        JOptionPane.showMessageDialog(this, "Customer added!");
        clearFields();
    }

    private void viewCustomers() {
        List<Customer> list = dao.getAllCustomers();
        displayArea.setText("");
        for (Customer c : list) {
            displayArea.append("Name: " + c.getName() +
                    " | Phone: " + c.getPhone() +
                    " | Email: " + c.getEmail() + "\n");
        }
    }

    private void clearFields() {
        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");
    }

    public static void main(String[] args) {
        new CustomerFrame();
    }
}
