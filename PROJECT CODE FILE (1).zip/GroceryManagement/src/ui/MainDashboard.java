package ui;

import javax.swing.*;
import java.awt.*;

public class MainDashboard extends JFrame {

    public MainDashboard() {
        setTitle("Grocery Management System - Dashboard");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1, 10, 10));

        JLabel title = new JLabel("GROCERY MANAGEMENT SYSTEM", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title);

        JButton productBtn = new JButton("🛒  Manage Products");
        JButton customerBtn = new JButton("👥  Manage Customers");
        JButton salesBtn = new JButton("💵  Sales & Billing");
        JButton exitBtn = new JButton("❌  Exit");

        productBtn.setFont(new Font("Arial", Font.PLAIN, 16));
        customerBtn.setFont(new Font("Arial", Font.PLAIN, 16));
        salesBtn.setFont(new Font("Arial", Font.PLAIN, 16));
        exitBtn.setFont(new Font("Arial", Font.PLAIN, 16));

        productBtn.addActionListener(e -> new ProductFrame());
        customerBtn.addActionListener(e -> new CustomerFrame());
        salesBtn.addActionListener(e -> new SalesFrame());
        exitBtn.addActionListener(e -> System.exit(0));

        add(productBtn);
        add(customerBtn);
        add(salesBtn);
        add(exitBtn);

        setLocationRelativeTo(null);  // center window
        setVisible(true);
    }

    public static void main(String[] args) {
        new MainDashboard();
    }
}
