package dao;

import db.DBConnection;
import java.sql.*;
import java.util.Map;

public class SalesDAO {

    // Map<product_id, quantity>  → products sold in the bill
    public void createSale(int customerId, Map<Integer, Integer> items) {
        Connection con = null;
        PreparedStatement saleStmt = null;
        PreparedStatement saleItemStmt = null;
        PreparedStatement updateQtyStmt = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            // 1) Calculate total
            double total = 0.0;
            for (Map.Entry<Integer, Integer> entry : items.entrySet()) {
                int productId = entry.getKey();
                int qty = entry.getValue();

                PreparedStatement ps = con.prepareStatement("SELECT price FROM products WHERE product_id=?");
                ps.setInt(1, productId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    total += rs.getDouble("price") * qty;
                }
                rs.close(); ps.close();
            }

            // 2) Insert into sales table
            String saleSQL = "INSERT INTO sales (customer_id, total_amount) VALUES (?, ?)";
            saleStmt = con.prepareStatement(saleSQL, Statement.RETURN_GENERATED_KEYS);
            saleStmt.setInt(1, customerId);
            saleStmt.setDouble(2, total);
            saleStmt.executeUpdate();

            ResultSet rs = saleStmt.getGeneratedKeys();
            rs.next();
            int saleId = rs.getInt(1);
            rs.close();

            // 3) Insert sale items and update stock
            saleItemStmt = con.prepareStatement(
                "INSERT INTO sale_items (sale_id, product_id, quantity, subtotal) VALUES (?, ?, ?, ?)"
            );
            updateQtyStmt = con.prepareStatement(
                "UPDATE products SET quantity = quantity - ? WHERE product_id = ?"
            );

            for (Map.Entry<Integer, Integer> entry : items.entrySet()) {
                int productId = entry.getKey();
                int qty = entry.getValue();

                PreparedStatement ps = con.prepareStatement("SELECT price FROM products WHERE product_id=?");
                ps.setInt(1, productId);
                ResultSet rs2 = ps.executeQuery();
                double price = 0;
                if (rs2.next()) price = rs2.getDouble("price");
                rs2.close(); ps.close();

                double subtotal = price * qty;

                saleItemStmt.setInt(1, saleId);
                saleItemStmt.setInt(2, productId);
                saleItemStmt.setInt(3, qty);
                saleItemStmt.setDouble(4, subtotal);
                saleItemStmt.executeUpdate();

                updateQtyStmt.setInt(1, qty);
                updateQtyStmt.setInt(2, productId);
                updateQtyStmt.executeUpdate();
            }

            con.commit();
            System.out.println("✅ Sale recorded successfully! Total: ₹" + total);

        } catch (SQLException e) {
            try {
                if (con != null) con.rollback();
            } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
        } finally {
            try {
                if (con != null) con.setAutoCommit(true);
                if (saleStmt != null) saleStmt.close();
                if (saleItemStmt != null) saleItemStmt.close();
                if (updateQtyStmt != null) updateQtyStmt.close();
                if (con != null) con.close();
            } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
