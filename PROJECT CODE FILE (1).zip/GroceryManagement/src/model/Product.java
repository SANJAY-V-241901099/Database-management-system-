package model;

public class Product {
    private int productId;
    private String name;
    private String category;
    private int quantity;
    private double price;

    public Product(int id, String name, String category, int qty, double price) {
        this.productId = id;
        this.name = name;
        this.category = category;
        this.quantity = qty;
        this.price = price;
    }

    public Product(String name, String category, int qty, double price) {
        this.name = name;
        this.category = category;
        this.quantity = qty;
        this.price = price;
    }

    public int getProductId() { return productId; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
}
